﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program
    {
        class Display
        {
            public IMyTextSurfaceProvider Provider;
            bool m_useSurfaceSize;

            public IMyTextSurface  Surface;
            public int             Index;
            public RectangleF      Viewport;
            public float           Scale;

            public float           ContentWidth;
            public float           ContentHeight;


            public Display(IMyTextSurfaceProvider provider, int index)
            {
                Provider = provider;
                Index    = index;
                Surface  = Provider.GetSurface(Index);
                m_useSurfaceSize = true;
        
                Init();
            }
            
            
            public Display(IMyTextSurface surface, bool useSurfaceSize = true)
            {
                Provider = null;
                Index    = -1;
                Surface  = surface;
                m_useSurfaceSize = useSurfaceSize;

                Init();
            }

            
            void Init()
            {
                Surface.ContentType = ContentType.SCRIPT;

                Scale = 1;

                ContentWidth  = 0;
                ContentHeight = 0;

		        Surface.Script = "";
		        Surface.ScriptBackgroundColor = Color.Black;

		        Viewport = new RectangleF((Surface.TextureSize - Surface.SurfaceSize) / 2, Surface.SurfaceSize);
	        }


            public float ContentScale
            {
                get 
                { 
                    return 
                          Math.Min(Surface.TextureSize.X, Surface.TextureSize.Y) / 512
                        * Math.Min(Surface.SurfaceSize.X, Surface.SurfaceSize.Y)
                        / Math.Min(Surface.TextureSize.Y, Surface.TextureSize.Y); 
                }
            }

            
            public float UserScale
            {
                get
                {
                    if (Scale == 0)
                    {
                        return
                            Surface.SurfaceSize.X / ContentWidth < Surface.SurfaceSize.Y / ContentHeight
                            ? (Surface.SurfaceSize.X - 10) / ContentWidth
                            : (Surface.SurfaceSize.Y - 10) / ContentHeight;
                    }
                    else return Scale;
                }
            }

            
            public void Add(ref MySpriteDrawFrame frame, List<MySprite> sprites)
            {
                foreach (var sprite in sprites)
                    Add(ref frame, sprite);
            }
            
            
            public void Add(ref MySpriteDrawFrame frame, MySprite sprite)
            {
                     if (sprite.Type == SpriteType.TEXT   ) sprite.RotationOrScale *= UserScale;
                else if (sprite.Type == SpriteType.TEXTURE) sprite.Size            *= UserScale;

                sprite.Position *= UserScale;

                sprite.Position += 
                      Viewport.Position 
                    + Viewport.Size/2 
                    - new Vector2(ContentWidth, ContentHeight)/2 * UserScale;
            
                frame.Add(sprite);
            }
        }
    }
}
