﻿namespace IngameScript
{
    partial class Program
    {
        const float FPS1 = 60;
        const float dt1  = 1/FPS1;

        const float FPS10 = 6;
        const float dt10  = 1/FPS10;
    }
}
