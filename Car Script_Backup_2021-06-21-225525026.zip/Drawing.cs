﻿using Sandbox.ModAPI.Ingame;
using System;
using System.Collections.Generic;
using VRage.Game.GUI.TextPanel;
using VRageMath;


namespace IngameScript
{
    partial class Program
    {
        static MySprite DrawString(string str, float x, float y, float scale, Color color, TextAlignment align = TextAlignment.LEFT)
        {
            return new MySprite()
            {
                Type            = SpriteType.TEXT,
                Data            = str,
                Position        = new Vector2(x, y),
                RotationOrScale = scale,
                Color           = color,
                Alignment       = align,
                FontId          = "Monospace"
            };
        }


        static MySprite DrawTex(string texture, Vector2 pos, Vector2 size, Color color, float rotation = 0)
        {
            return new MySprite()
            {
                Type            = SpriteType.TEXTURE,
                Data            = texture,
                Position        = pos + size/2,
                Size            = size,
                Color           = color,
                Alignment       = TextAlignment.CENTER,
                RotationOrScale = rotation
            };
        }


        static MySprite DrawTex(string texture, float x, float y, float w, float h, Color color, float rotation = 0)
        {
            return DrawTex(texture, new Vector2(x, y), new Vector2(w, h), color, rotation);
        }


        static MySprite DrawLine(Vector2 p1, Vector2 p2, Color color, double width = 1)
        {
            var dp = p2 - p1;
            var length = dp.Length();
            var angle = (float)Math.Atan2(p1.Y - p2.Y, p2.X - p1.X);

            return DrawTex(
                "SquareSimple",
                p1.X + dp.X/2 - length/2,
                p1.Y + dp.Y/2 - (float)width/2,
                length,
                (float)width,
                color,
               -angle);
        }


        static MySprite DrawLine(double x1, double y1, double x2, double y2, Color color, double width = 1)
        {
            return DrawLine(new Vector2((float)x1, (float)y1), new Vector2((float)x2, (float)y2), color, width);
        }


        static MySprite FillRect(float x, float y, float w, float h, Color color)
        {
            return DrawTex("SquareSimple", x, y, w, h, color);
        }


        static List<MySprite> DrawCabin(float x, float y, float size)
        {
            var sprites = new List<MySprite>();

            var colCabin  = new Color(0x22, 0x22, 0x22);
            var colWindow = new Color(0x04, 0x04, 0x04);

            sprites.Add(FillRect(x, y, size * 0.333f, size, colCabin));
            sprites.Add(FillRect(x, y + size * 0.7f, size, size*0.3f, colCabin));
	        sprites.Add(DrawTex("RightTriangle", x + size*0.333f, y, size*0.666f, size*0.7f, colCabin));

            sprites.Add(FillRect(x + size*0.07f, y + size*0.07f,                 size*0.25f, size*0.63f, colWindow));
	        sprites.Add(DrawTex("RightTriangle", x + size*0.32f, y + size*0.07f, size*0.6f,  size*0.63f, colWindow));

	        return sprites;
        }


        static List<MySprite> DrawCargo(float x, float y, float size, float mass, float full)
        {
            var colBack = new Color(0x22, 0x22, 0x22);
            var colFull = new Color(0x44, 0x44, 0x44);
            var colText = new Color(0x66, 0x66, 0x66);

            var sprites = new List<MySprite>();

            sprites.Add(FillRect(x, y, size, size, colBack));
            sprites.Add(FillRect(x, y + (1 - full) * size, size, full * size, colFull));

            var cornerSize = 7;

	        sprites.Add(DrawTex("RightTriangle", x,        y + cornerSize,         cornerSize, -cornerSize, Color.Black));
	        sprites.Add(DrawTex("RightTriangle", x + size, y + cornerSize,        -cornerSize, -cornerSize, Color.Black));
	        sprites.Add(DrawTex("RightTriangle", x,        y + size - cornerSize,  cornerSize,  cornerSize, Color.Black));
	        sprites.Add(DrawTex("RightTriangle", x + size, y + size - cornerSize, -cornerSize,  cornerSize, Color.Black));

            sprites.Add(DrawString(printMass(mass), x + size/2 - 5, y + (1 - full) * size - 13, 0.3f, Color.Gray, TextAlignment.CENTER));

            return sprites;
        }


        static List<MySprite> DrawWheel(float x, float y, float ww)
        {
            var sprites = new List<MySprite>();

            var colWheel = new Color(0x0c, 0x0c, 0x0c);
            var colHub   = new Color(0x22, 0x22, 0x22);

            var wh = ww/3;

            sprites.Add(DrawTex("Circle", x - ww/2, y - ww/2, ww, ww, colWheel));
            sprites.Add(DrawTex("Circle", x - wh/2, y - wh/2, wh, wh, colHub));

            return sprites;
        }


        static List<MySprite> DrawSuspension(float x, float y, float w, float h, float strength)
        {
            var sprites = new List<MySprite>();

            var col = Color.Gray;

            strength /= 2;

            sprites.Add(DrawLine(x, y, x+w, y, col, 2));

            var so = 0.6f;

            for (int i = 1; i < (int)strength; i++)
            {
                var iy = y + 1 + i / strength * h;
                sprites.Add(DrawLine(x, iy + so, x+w, iy - so, col, 1));
	        }

            sprites.Add(DrawLine(x, y+h, x+w, y+h, col, 2));

            return sprites;
        }


        static List<MySprite> DrawCollector(float x, float y, float size, float mass, float full)
        {
            var sprites = new List<MySprite>();

            var colBack = new Color(0x22, 0x22, 0x22);
            var colFull = new Color(0x33, 0x33, 0x33);
            var colText = new Color(0x66, 0x66, 0x66);

            sprites.Add(FillRect(x, y, size, size, colBack));
            sprites.Add(FillRect(x, y + (1 - full) * size, size, full * size, colFull));

            var cornerSize = 7;

	        sprites.Add(DrawTex("RightTriangle", x + cornerSize,        y + cornerSize,        -cornerSize, -cornerSize, Color.Black));
	        sprites.Add(DrawTex("RightTriangle", x + size - cornerSize, y + cornerSize,       cornerSize, -cornerSize, Color.Black));
	        sprites.Add(DrawTex("RightTriangle", x,        y + size - cornerSize,  cornerSize,  cornerSize, Color.Black));
	        sprites.Add(DrawTex("RightTriangle", x + size, y + size - cornerSize, -cornerSize,  cornerSize, Color.Black));
            sprites.Add(FillRect(x + cornerSize, y, size - cornerSize*2, cornerSize, Color.Black));

            sprites.Add(DrawString(printMass(mass), x + size/2, y + (1 - full) * size - 13, 0.3f, Color.Gray, TextAlignment.CENTER));

            return sprites;
        }


        static List<MySprite> DrawConnector(float x, float y, float w, float h, IMyShipConnector connector)
        {
            var sprites = new List<MySprite>();

            if (connector == null)
                return sprites;


            var colBody = new Color(0x22, 0x22, 0x22);
            var colOff  = new Color(0x08, 0x08, 0x08);
            var colOut  = new Color(0x55, 0x55, 0x55);
            var colUn   = new Color(0x66, 0x66, 0x66);
            var colAble = new Color(0x66, 0x55, 0   );
            var colConn = new Color(0,    0x66, 0   );

            var col = colUn;
            if (connector.Status == MyShipConnectorStatus.Connectable) col = colAble;
            if (connector.Status == MyShipConnectorStatus.Connected)   col = colConn;
 
            sprites.Add(FillRect(x, y, w, h, colBody));

            if (connector.Enabled)  
            { 
                sprites.Add(DrawString("EJECT",   13, 13, 0.36f, connector.ThrowOut   ? colOut : colOff));
                sprites.Add(DrawString("COLLECT", 63, 13, 0.36f, connector.CollectAll ? colOut : colOff));

                sprites.Add(DrawLine(x-1, y, x-1, y+h, col, 3));
            }

            return sprites;
        }
    }
}
