﻿using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using VRage.Game.GUI.TextPanel;
using VRageMath;


namespace IngameScript
{
    partial class Program
    {
        public void Main(string arg, UpdateType update)
        {
            arg = arg.Trim().ToLower();

            //if (arg == "far lights") 
            //{ 
            //    m_farLights = !m_farLights; 

            //    if (m_farLights)
            //    { 
            //        foreach (var h in m_headlights)
            //            h.Enabled = true;
            //    }

            //    return; 
            //}

            //else 
            if (arg == "help")  { m_help = !m_help; return; }

            else if (arg == "emergency")  { m_emergency = !m_emergency; return; }

            else if (arg == "auto lights")  { m_autoLights = !m_autoLights; return; }
    
            else if (arg == "speed limit down")
            {
                foreach (var lw in m_lWheels) lw.SetValueFloat("Speed Limit", lw.GetValueFloat("Speed Limit") - 30);
                foreach (var rw in m_rWheels) rw.SetValueFloat("Speed Limit", rw.GetValueFloat("Speed Limit") - 30);
                return;
	        }

            else if (arg == "speed limit up")
            {
                foreach (var lw in m_lWheels) lw.SetValueFloat("Speed Limit", lw.GetValueFloat("Speed Limit") + 30);
                foreach (var rw in m_rWheels) rw.SetValueFloat("Speed Limit", rw.GetValueFloat("Speed Limit") + 30);
                return;
	        }

            else if (arg == "reset ground level")
                m_groundLevel -= m_altitude;


         //   if (arg == "kneel")
         //   {
         //       m_kneel = !m_kneel;

         //       if (   m_kneel
         //           && m_cockpit.IsUnderControl)
         //           m_kneelFromInside = true;
	        //}


            var baseMass = 
                m_cockpit != null 
                ? m_cockpit.CalculateShipMass().BaseMass 
                : 0;

            Echo("1");
            if ((update & UpdateType.Update1) != 0)
            {
		        if (m_cockpit != null)
		        {
                    m_move = m_cockpit.MoveIndicator;

                    m_rotate = new Vector3(
                        m_cockpit.RotationIndicator.X,
                        m_cockpit.RotationIndicator.Y,
                        m_cockpit.RollIndicator);


                    UpdateLocation();
                    UpdateVelocity();


                    var brake = m_move.Y > 0.1;

                    m_braking = 
                           brake
                        || m_brakeStarted
                        ||    m_move.Z > 0 && -m_linVelocity.Z < 0 
                           && !(   Math.Abs(m_move.Z) < 0.1f
                                || Math.Abs(m_linVelocity.Z) < 0.1f) 
                           && Math.Abs(m_move.Z + m_linVelocity.Z) > 0.1f;


                    if (!m_brakeStarted && m_braking)
                        m_brakeStarted = true;
                    else if (Math.Abs(m_move.Z) < 0.1f)
                        m_brakeStarted = false;


                    if (brake)
                        m_cruiseControl = false;


                    if (m_cruiseControl)
                    {
                        m_ccSpeed += -m_move.Z * 0.04f;
                        m_ccSpeed = Math.Max(-m_reverseSpeedLimit/3.6f, m_ccSpeed);
                        m_ccSpeed = Math.Min(m_ccSpeed, m_speedLimit/3.6f);

                        var moveZ = -(m_ccSpeed - m_linVelocity.Z) * 0.5f;

                        if (m_reversing)
                            moveZ *= 1 - (float)Math.Pow(Math.Min(Math.Max(0, m_linVelocity.Z / (-m_reverseSpeedLimit/3.6f)), 1), 2);

                        m_propulsion += (moveZ - m_propulsion) * 0.05f;

                        m_brakeSpeed = 0;
                    }
                    else if (m_braking)
                    {   
                        if (m_brakeSpeed == 0)
                            m_brakeSpeed = -m_linVelocity.Z;

                        if (m_brakeSpeed != 0)
                        {
                            m_propulsion = 
                                brake
                                ? m_linVelocity.Z / (4 - Math.Min((m_mass-baseMass) / 120000 * 3, 3))
                                : m_linVelocity.Z / (12 - Math.Min((m_mass-baseMass) / 120000 * 11, 11));
                        }
                    }
                    else
                    {
                        var moveZ = m_move.Z;

                        if (m_reversing)
                            moveZ *= 1 - (float)Math.Pow(Math.Min(Math.Max(0, m_linVelocity.Z / (-m_reverseSpeedLimit/3.6f)), 1), 2);

                        m_propulsion += (moveZ - m_propulsion) * 0.05f;

                        m_brakeSpeed = 0;
                    }


                    if (m_cruiseControl)
                    {
                        m_ccHeading += m_move.X * 0.17f;

                        while (m_ccHeading >= 360) m_ccHeading -= 360;
                        while (m_ccHeading <    0) m_ccHeading += 360;

                        var turn = (m_ccHeading - m_heading) * 5;
                        while (turn < -180) turn += 360;
                        while (turn >  180) turn -= 360;
                        turn /= 180;

                        m_steering += (turn - m_steering) * 0.5f;
                        m_steer = Math.Min(Math.Max(-1, m_steer + (m_steering - m_steer) * 0.5f), 1);
			        }
                    else
                    {
                        m_steering += (m_move.X - m_steering) * 0.04f;
                        m_steer = Math.Min(Math.Max(-1, m_steer + (m_steering - m_steer) * 0.04f), 1);
			        }



                    if (Math.Abs(m_steer) > 0.3f)
                        m_turning = true;
                    else if (m_turning)
                    {
                        m_turningLeft  = false;
                        m_turningRight = false;
                        m_turning      = false;
			        }


                    if (m_rotate.Z < -0.9f)
                    {
                        if (!m_pressedLeft)
                        {
                            m_pressedLeft = true;
                            m_counterLeft = m_pressCount;
                        }
                        else if (m_counterLeft > 0)
                            m_counterLeft--;
			        }
                    else
                    { 
                        if (m_counterLeft > 0)
                        {
                            if (m_turningRight) m_turningRight = false;
                            else                m_turningLeft  = true;
                        }

                        m_pressedLeft = false;
                        m_counterLeft = 0;
                    }


                    if (m_rotate.Z > 0.9f)
                    {
                        if (!m_pressedRight)
                        {
                            m_pressedRight = true;
                            m_counterRight = m_pressCount;
                        }
                        else if (m_counterRight > 0)
                            m_counterRight--;
			        }
                    else
                    { 
                        if (m_counterRight > 0)
                        {
                            if (m_turningLeft) m_turningLeft  = false;
                            else               m_turningRight = true;
                        }

                        m_pressedRight = false;
                        m_counterRight = 0;
                    }
            
            
                    if (m_linVelocity.Z < -0.1f)
                    { 
                        if (m_move.Z > 0.1f && !m_braking)
                            m_reversing = true;
                        else if (m_move.Z < -0.1f)
                            m_reversing = false;
                    }


                    if (   m_reversing 
                        && !m_prevReversing 
                        && m_reverseBeep)
                    {
                        foreach (var s in m_beepBlocks)
                        {
                            s.LoopPeriod = 1800;
                            s.Play();
			            }
			        }
                    else if (!m_reversing 
                          && m_prevReversing)
                    {
                        foreach (var s in m_beepBlocks)
                        {
                            s.LoopPeriod = 0;
                            s.Stop();
                        }
                    }


			        m_prevReversing = m_reversing;


                    if (m_move.Y == -1)
                    {
                        if (!m_ccPressed)
                        {
                            m_ccPressed = true;
                            m_ccCounter = m_pressCount;
                        }
                        else if (m_counterLeft > 0)
                            m_ccCounter--;
                    }
                    else
                    {
                        if (m_ccCounter > 0)
                        {
                            m_cruiseControl = !m_cruiseControl;

                            if (m_cruiseControl)
                            {
                                m_ccSpeed = m_linVelocity.Z;
                                m_ccHeading = m_heading;
                            }
                        }

                        m_ccPressed = false;
                        m_ccCounter = 0;
                    }
                }
            }

            Echo("2");
            if ((update & UpdateType.Update10) != 0)
            {
                if (   m_autoHandbrake
                    && m_cockpit != null
                    && !m_cockpit.IsUnderControl)
                    m_cockpit.HandBrake = true;


                Echo("2.1");
                var uphill = 6;

                var dk = 0.1f / (1 + 3 * (m_mass - baseMass) / 120000);
                Echo("2.2");

                //if (m_kneel) m_kneelState = Math.Max(0, m_kneelState - dk);
                //else         m_kneelState = Math.Min(m_kneelState + dk, 1);

                Echo("2.3");

                if (m_cockpit != null)
                {
                    Echo("2.4");
                    if (m_cockpit.HandBrake)
                        m_cruiseControl = false;


                    Echo("2.5");
                    if (   m_cockpit.HandBrake
                        && Math.Abs(m_linVelocity.Z) < 1
                        && m_crouchPark) // park
                    {
                        var ck = 1;// / (1 + (m_mass - baseMass) / 120000);
                    
                        m_parked = true;

                        for (int i = 0; i < m_susp.Count; i++)
                        { 
                            m_susp[i] = Math.Max(0, m_susp[i] - ck);
                            if (m_susp[i] > 0) m_parked = false;
                        }
		            }
                    else if (m_susp.Count == 4) // moving
                    {
                        var defSusp = 5.5f;

                        var susp0 = defSusp;//(defSusp + 8 * m_cargo1mass / 40000) * m_kneelState;
                        var susp1 = defSusp;//(defSusp + 8 * m_cargo2mass / 40000) * (0.5f + m_kneelState/2);
                        var susp2 = defSusp;// defSusp + 8 * m_cargo3mass / 40000;
                        var susp3 = defSusp;// defSusp + 1 + 8 * m_rearMass / 40000;

                        if (m_parked)
                        {
                            var ck = 1;// / (1 + (m_mass - baseMass) / 120000);

                            m_susp[0] = Math.Min(m_susp[0] + ck, susp0);
                            m_susp[1] = Math.Min(m_susp[1] + ck, susp1);
                            m_susp[2] = Math.Min(m_susp[2] + ck, susp2);
                            m_susp[3] = Math.Min(m_susp[3] + ck, susp3);

                            if (   m_susp[0] > susp0 - 0.5f
                                && m_susp[1] > susp1 - 0.5f
                                && m_susp[2] > susp2 - 0.5f
                                && m_susp[3] > susp3 - 0.5f)
                                m_parked = false;
				        }
                        else
                        { 
                            m_susp[0] = susp0;
                            m_susp[1] = susp1;
                            m_susp[2] = susp2;
                            m_susp[3] = susp3;
                        }
                    }
                    Echo("2.6");
                }

                Echo("2.7");

                for (int i = 0; i < m_lWheels.Count; i++)
                {
                    var lw = m_lWheels[i];

                    lw.Power = Math.Min(
                          30 
                        + 70 * Math.Abs(m_linVelocity.Z)/100
                        + 40 * m_orientation.X*uphill 
                        + 40 * (m_mass-baseMass) / 120000,
                        100); 
            
                    lw.SetValueFloat("Propulsion override", m_propulsion * lw.Power/200);
                    if (m_susp.Count == m_lWheels.Count) lw.Strength = m_susp[i];
		        }

                Echo("2.8");
                for (int i = 0; i < m_rWheels.Count; i++)
                {
                    var rw = m_rWheels[i];

                    rw.Power = Math.Min(
                          30 
                        + 70 * Math.Abs(m_linVelocity.Z)/100
                        + 40 * m_orientation.X*uphill 
                        + 40 * (m_mass-baseMass) / 120000,
                        100); 

                    rw.SetValueFloat("Propulsion override", -m_propulsion * rw.Power/200);
                    if (m_susp.Count == m_rWheels.Count) rw.Strength = m_susp[i];
                }

                Echo("2.9");

                var diff = 1f;

                if (   m_flw != null
                    && m_frw != null
                    && m_rlw != null
                    && m_rrw != null)
                {
                    if (m_steer < 0)
                    {
                        var pfl = GetWheelPosition(m_flw, -1);
                        var prl = GetWheelPosition(m_rlw, -1);

                        var fla = Math.Max(-1, m_steer) * m_flw.MaxSteerAngle - Tau/2;
                        var rla = -Tau/2;

				        var vfl = vector2(fla, 1);
                        var vrl = vector2(rla, 1);

                        var pt  = intersect(pfl, vfl, prl, vrl);

                        if (!Vector2_IsNaN(pt))
                        {
                            foreach (var lw in m_lWheels) 
                            {
                                var a = angle(GetWheelPosition(lw, -1) - pt);
                                lw.SetValueFloat("Steer override", a / m_flw.MaxSteerAngle); 
                            }
                            foreach (var rw in m_rWheels) 
                            {
                                var a = angle(GetWheelPosition(rw, 1) - pt);
                                rw.SetValueFloat("Steer override", a / m_flw.MaxSteerAngle); 
                            }


                            var pfr = GetWheelPosition(m_frw, 1);

                            diff = Vector2.Distance(pt, pfl) / Vector2.Distance(pt, pfr);

                            foreach (var lw in m_lWheels) lw.Power *= diff;
                            foreach (var rw in m_rWheels) rw.Friction = diff * 100;
				        }
		            }
                    else if (m_steer > 0)
                    {
                        var pfr = GetWheelPosition(m_frw, 1);
                        var prr = GetWheelPosition(m_rrw, 1);

                        var fra = m_steer * m_frw.MaxSteerAngle;
                        var rra = 0;

                        var vfr = vector2(fra, 1);
                        var vrr = vector2(rra, 1);

                        var pt  = intersect(pfr, vfr, prr, vrr);
                
                        if (!Vector2_IsNaN(pt))
                        {
					        foreach (var rw in m_rWheels)
					        {
						        var a = angle(GetWheelPosition(rw, 1) - pt) + Tau / 2;
						        if (a > Tau / 2) a -= Tau;
						        rw.SetValueFloat("Steer override", a / m_frw.MaxSteerAngle);
					        }
					        foreach (var lw in m_lWheels) 
                            {
                                var a = angle(GetWheelPosition(lw, -1) - pt) + Tau/2;
                                if (a > Tau/2) a -= Tau;
                                lw.SetValueFloat("Steer override", a / m_frw.MaxSteerAngle); 
                            }


                            var pfl = GetWheelPosition(m_flw, -1);

                            diff = Vector2.Distance(pt, pfr) / Vector2.Distance(pt, pfl);

                            foreach (var rw in m_rWheels) rw.Power *= diff;
                            foreach (var lw in m_lWheels) lw.Friction = diff * 100;
				        }
		            }
                }
                else
                {
                    foreach (var lw in m_lWheels) lw.SetValueFloat("Steer override", m_steering * (lw.Position.Z < m_midZ ? -1 : 1) * (lw.Position.Z - m_maxZ) / (m_minZ - m_maxZ));
                    foreach (var rw in m_rWheels) rw.SetValueFloat("Steer override", m_steering * (rw.Position.Z < m_midZ ? -1 : 1) * (rw.Position.Z - m_maxZ) / (m_minZ - m_maxZ));
		        }

                Echo("2.10");

                //m_lightsOn = true;
                //foreach (var h in m_headlights) 
                //    if (!h.Enabled) { m_lightsOn = false; break; }


                //foreach (var h in m_headlights)
                //    h.SetValueFloat("Intensity", m_farLights ? 5f : 1.5f);


                var blink10 = 1 / dt10;

                var colBrake = new Color(0xff, 0, 0);
                var colTurn  = new Color(0xff, 0x88, 0);
                var colRev   = Color.White;


                if (m_lightFL != null) 
                {
                    m_lightFL.BlinkIntervalSeconds = 10;
                    m_lightFL.Enabled = m_turningLeft || m_emergency;
                    m_lightFL.BlinkLength = (m_count10 - 1) % blink10 < blink10/2 ? 100 : 0; 
                }

                if (m_lightFR != null) 
                {
                    m_lightFR.BlinkIntervalSeconds = 10;
                    m_lightFR.Enabled = m_turningRight || m_emergency;
                    m_lightFR.BlinkLength = (m_count10 - 1) % blink10 < blink10/2 ? 100 : 0; 
                }


                if (m_lightBL != null) 
                {
                    if (m_braking
                        ||    (m_cockpit == null || m_cockpit.HandBrake)
                           && !m_emergency)
                    {
                        m_lightBL.Enabled              = true;
                        m_lightBL.Color                = colBrake;
                        m_lightBL.BlinkIntervalSeconds = 0;
                        m_lightBL.BlinkLength          = 0;
                        m_lightBL.SetValueFloat("Intensity", 7);
                        m_lightBL.SetValueFloat("Radius", 5);
			        }
                    else if (m_emergency)
                    {
                        m_lightBL.Enabled              = true;
                        m_lightBL.Color                = colTurn;
                        m_lightBL.BlinkIntervalSeconds = 10;
                        m_lightBL.BlinkLength          = (m_count10 - 1) % blink10 < blink10/2 ? 100 : 0;
                        m_lightBL.SetValueFloat("Intensity", 5);
                        m_lightBL.SetValueFloat("Radius", 4);
			        }
                    else if (m_reversing)
                    {
                        m_lightBL.Enabled              = true;
                        m_lightBL.Color                = colRev;
                        m_lightBL.BlinkIntervalSeconds = 0;
                        m_lightBL.BlinkLength          = 0;
                        m_lightBL.SetValueFloat("Intensity", 5);
                        m_lightBL.SetValueFloat("Radius", 4);
			        }
                    else if (m_turningLeft)
                    {
                        m_lightBL.Enabled              = true;
                        m_lightBL.Color                = colTurn;
                        m_lightBL.BlinkIntervalSeconds = 10;
                        m_lightBL.BlinkLength          = (m_count10 - 1) % blink10 < blink10/2 ? 100 : 0;
                        m_lightBL.SetValueFloat("Intensity", 5);
                        m_lightBL.SetValueFloat("Radius", 2);
			        }
                    else
                    {
                        m_lightBL.Enabled = m_lightsOn;

                        if (m_lightsOn)
                            m_lightBL.Color = colBrake;

                        m_lightBL.BlinkIntervalSeconds = 0;
                        m_lightBL.BlinkLength          = 0;
                        m_lightBL.SetValueFloat("Intensity", 2);
                        m_lightBL.SetValueFloat("Radius", 1.5f);
			        }
                }

                if (m_lightBR != null) 
                {
                    if (m_braking
                        ||    (m_cockpit == null || m_cockpit.HandBrake)
                           && !m_emergency)
                    {
                        m_lightBR.Enabled              = true;
                        m_lightBR.Color                = colBrake;
                        m_lightBR.BlinkIntervalSeconds = 0;
                        m_lightBR.BlinkLength          = 0;
                        m_lightBR.SetValueFloat("Intensity", 7);
                        m_lightBR.SetValueFloat("Radius", 5);
			        }
                    else if (m_emergency)
                    {
                        m_lightBR.Enabled              = true;
                        m_lightBR.Color                = colTurn;
                        m_lightBR.BlinkIntervalSeconds = 10;
                        m_lightBR.BlinkLength          = (m_count10 - 1) % blink10 < blink10/2 ? 100 : 0;
                        m_lightBR.SetValueFloat("Intensity", 5);
                        m_lightBR.SetValueFloat("Radius", 4);
			        }
                    else if (m_reversing)
                    {
                        m_lightBR.Enabled              = true;
                        m_lightBR.Color                = colRev;
                        m_lightBR.BlinkIntervalSeconds = 0;
                        m_lightBR.BlinkLength          = 0;
                        m_lightBR.SetValueFloat("Intensity", 5);
                        m_lightBR.SetValueFloat("Radius", 4);
			        }
                    else if (m_turningRight)
                    {
                        m_lightBR.Enabled              = true;
                        m_lightBR.Color                = colTurn;
                        m_lightBR.BlinkIntervalSeconds = 10;
                        m_lightBR.BlinkLength          = (m_count10 - 1) % blink10 < blink10/2 ? 100 : 0;
                        m_lightBR.SetValueFloat("Intensity", 5);
                        m_lightBR.SetValueFloat("Radius", 2);
			        }
                    else
                    {
                        m_lightBR.Enabled = m_lightsOn;

                        if (m_lightsOn)
                            m_lightBR.Color = colBrake;

                        m_lightBR.BlinkIntervalSeconds = 0;
                        m_lightBR.BlinkLength          = 0;
                        m_lightBR.SetValueFloat("Intensity", 2);
                        m_lightBR.SetValueFloat("Radius", 1.5f);
			        }
                }

		
                if (   m_cockpit != null
                    && m_cockpit.IsWorking)
		        {
                    Echo("2.11");
                    UpdateOrientation();
                    UpdateLatitudeAndLongitude();
                    Echo("2.12");


                    m_display0.ContentWidth  = m_display0.Viewport.Width;
                    m_display0.ContentHeight = m_display0.Viewport.Height;

                    Echo("2.13");

                    var frame0 = m_display0.Surface.DrawFrame();

                    Echo("2.14");

                    var colGauge   = new Color(0x0c, 0x0c, 0x0c);
                    var colLabel   = new Color(0x55, 0x44, 0x33);
                    var colWarning = new Color(0x44, 0, 0);
                    var colShadow  = new Color(0x00, 0x00, 0x00, 0x40);
                    var colArrow   = new Color(0x88, 0x33, 0x00);


                    Echo("2.15");
                    // tachometer

                    var tSize = 80;

			        var xp = m_display0.Viewport.Center.X + 42 - 95;
			        var yp = m_display0.Viewport.Center.Y - 50;

                    Echo("2.16");
                    m_display0.Add(ref frame0, DrawTex("Circle",     xp - tSize/2, yp - tSize/2, tSize, tSize, colGauge));
                    m_display0.Add(ref frame0, DrawTex("SemiCircle", xp - tSize/2*0.98f, yp - tSize/2*0.98f, tSize*0.98f, tSize*0.98f, colWarning, -Tau/4));
                    m_display0.Add(ref frame0, DrawTex("SemiCircle", xp - tSize/2, yp - tSize/2, tSize, tSize, colGauge, -Tau/4 - Tau/10));
                    m_display0.Add(ref frame0, DrawTex("Circle",     xp - tSize/2*0.74f, yp - tSize/2*0.74f, tSize*0.74f, tSize*0.74f, colGauge));

                    m_display0.Add(ref frame0, DrawTex("Circle", xp - 1.8f*tSize/2 + 88, yp - 1.8f*tSize/2, 1.8f*tSize, 1.8f*tSize, Color.Black));

			        m_display0.Add(ref frame0, DrawString("%", xp - 18, yp - 9, 0.5f, colLabel, TextAlignment.CENTER));

                    Echo("2.17");
                    for (float p = 0; p <= 100; p += 20)
                    {
                        var v = vector2(Tau*1/4f + p/100 * Tau/2, tSize/2 + 5);
    			        m_display0.Add(ref frame0, DrawString(printValue(p, 0, true, 0), xp + v.X*1.02f, yp + v.Y*1.02f * 1.1f - 5, 0.35f, Color.Gray, p < 20 || p > 80 ? TextAlignment.CENTER : TextAlignment.RIGHT));
    			        m_display0.Add(ref frame0, DrawLine(xp + v.X*0.7, yp + v.Y*0.7f, xp + v.X*0.89f, yp + v.Y*0.89f, Color.Gray, 3));
			        }
                    Echo("2.18");


                    var avgPower = 0f;

                    foreach (var lw in m_lWheels) avgPower += lw.Power;
                    foreach (var rw in m_rWheels) avgPower += rw.Power;

                    if (   m_lWheels.Count > 0
                        || m_rWheels.Count > 0)
                        avgPower /= m_lWheels.Count + m_rWheels.Count;
                    Echo("2.19");

                    var propulsion = m_propulsion * avgPower/100;
                    Echo("2.20");

                    Echo("m_dspPower = " + m_dspPower);
                    Echo("m_linVelocity.Z = " + m_linVelocity.Z);
                    Echo("m_propulsion = " + propulsion);

                    m_dspPower += 
                        Math.Sign(propulsion) == Math.Sign(-m_linVelocity.Z) 
                        ? (propulsion - m_dspPower) * 0.4f
                        : -m_dspPower * 0.4f;

                    Echo("2.21");

                    var vp = vector2(Tau*1/4f + (float)Math.Min(Math.Abs(m_dspPower), 1) * Tau/2, tSize/2);
    		        m_display0.Add(ref frame0, DrawLine(xp, yp + 4, xp + vp.X, yp + vp.Y + 4, colShadow, 9));
                    m_display0.Add(ref frame0, DrawTex("Circle", xp - 7, yp - 7 + 4, 14, 14, colShadow));
    		        m_display0.Add(ref frame0, DrawLine(xp, yp, xp + vp.X, yp + vp.Y, colArrow, 5));
                    m_display0.Add(ref frame0, DrawTex("Circle", xp - 5, yp - 5, 10, 10, colArrow));

                    Echo("2.22");

                    // speedometer

                    var sSize = 100;

			        var xs = m_display0.Viewport.Center.X + 39;
			        var ys = m_display0.Viewport.Center.Y - 50;

                    m_display0.Add(ref frame0, DrawTex("Circle", xs - sSize/2, ys - sSize/2, sSize, sSize, colGauge));

			        m_display0.Add(ref frame0, DrawString("km/h", xs, ys + 25, 0.45f, colLabel, TextAlignment.CENTER));

                    Echo("2.23");

                    m_speedLimit = 0f;

                    foreach (var lw in m_lWheels) m_speedLimit += lw.GetValueFloat("Speed Limit");
                    foreach (var rw in m_rWheels) m_speedLimit += rw.GetValueFloat("Speed Limit");

                    if (   m_lWheels.Count > 0
                        || m_rWheels.Count > 0)
                        m_speedLimit /= m_lWheels.Count + m_rWheels.Count;
            

                    for (float f = 0; f <= 360; f += 30)
                    {
                        var v = vector2(Tau*3/8f + f/360 * Tau*3/4f, sSize/2 + 5);
                        var c = f <= m_speedLimit ? Color.Gray : new Color(0x08, 0x08, 0x08);
    			        m_display0.Add(ref frame0, DrawString(printValue(f, 0, true, 0), xs + v.X, ys + v.Y * 1.1f - 5, 0.35f, c, f < 180 ? TextAlignment.RIGHT : (f > 180 ? TextAlignment.LEFT : TextAlignment.CENTER)));
    			        m_display0.Add(ref frame0, DrawLine(xs + v.X*0.73, ys + v.Y*0.73f, xs + v.X*0.895f, ys + v.Y*0.895f, c, 2.5));
			        }
                    Echo("2.24");

                    m_dspSpeed += (m_linVelocity.Z - m_dspSpeed) * 0.5f;

                    var va = vector2(Tau*3/8f + (float)Math.Abs(m_dspSpeed/100) * Tau*3/4f, sSize/2);
    		        m_display0.Add(ref frame0, DrawLine(xs, ys + 4, xs + va.X, ys + va.Y + 4, colShadow, 9));
                    m_display0.Add(ref frame0, DrawTex("Circle", xs - 7, ys - 7 + 4, 14, 14, colShadow));
    		        m_display0.Add(ref frame0, DrawLine(xs, ys, xs + va.X, ys + va.Y, colArrow, 5));
                    m_display0.Add(ref frame0, DrawTex("Circle", xs - 5, ys - 5, 10, 10, colArrow));


                    // fuel gauge

                    var fSize = 50;

			        var xf = 38;
			        var yf = m_display0.Viewport.Center.Y + 84;

                    m_display0.Add(ref frame0, DrawTex("Circle", xf - fSize/2, yf - fSize/2, fSize, fSize, colGauge));
                    m_display0.Add(ref frame0, DrawTex("SemiCircle", xf - fSize/2*0.95f, yf - fSize/2*0.95f, fSize*0.95f, fSize*0.95f, colWarning, Tau/2 + Tau*3/8f));
                    m_display0.Add(ref frame0, DrawTex("SemiCircle", xf - fSize/2, yf - fSize/2, fSize, fSize, colGauge, Tau/2 + Tau*3/8f + Tau*3/16));
                    m_display0.Add(ref frame0, DrawTex("Circle", xf - fSize/2*0.7f, yf - fSize/2*0.7f, fSize*0.7f, fSize*0.7f, colGauge));
                    Echo("2.25");

                    m_display0.Add(ref frame0, DrawTex("IconEnergy", xf-8, yf-8 + 16, 16, 16, colLabel));

                    for (float f = 0; f <= 1.000001; f += 0.25f)
                    {
                        var v = vector2(Tau*3/8f + f * Tau*3/4f, fSize/2 + 5);
    			        m_display0.Add(ref frame0, DrawLine(xf + v.X*0.6, yf + v.Y*0.6f, xf + v.X*0.8f, yf + v.Y*0.8f, Color.Gray, 2));
			        }
                    Echo("2.26");

                    var ve = vector2(Tau*3/8f, fSize/2 + 5);
   			        m_display0.Add(ref frame0, DrawString("E", xf + ve.X*1.1f, yf + ve.Y*1.1f, 0.35f, Color.Gray, TextAlignment.CENTER));

                    var vf = vector2(Tau*3/8f + Tau*3/4f, fSize/2 + 5);
   			        m_display0.Add(ref frame0, DrawString("F", xf + vf.X*1.1f, yf + vf.Y*1.1f, 0.35f, Color.Gray, TextAlignment.CENTER));


                    //      var bp = m_curBatteryPower / m_maxBatteryPower;
                    //      var vpf = vector2(Tau*3/8f + bp * Tau*3/4f, fSize/2);
                    //m_display0.Add(ref frame0, DrawLine(xf, yf + 4, xf + vpf.X, yf + vpf.Y + 4, colShadow, 9));
                    //      m_display0.Add(ref frame0, DrawTex("Circle", xf - 5, yf - 5 + 4, 14, 14, colShadow));
                    //m_display0.Add(ref frame0, DrawLine(xf, yf, xf + vpf.X, yf + vpf.Y, colArrow, 3));
                    //      m_display0.Add(ref frame0, DrawTex("Circle", xf - 4, yf - 4, 10, 10, colArrow));


                    //         // battery light
                    //         var pcl = new Vector2(90, m_display0.Viewport.Bottom - 55);

                    //         var nCharging = 0;
                    //         var batCur = 0f;
                    //         var batMax = 0f;

                    //         foreach (var b in m_batteries)
                    //         {
                    //             if (b.ChargeMode != ChargeMode.Recharge) nCharging++;
                    //             batCur += b.CurrentOutput;
                    //             batMax += b.MaxOutput;
                    //         }

                    //         var clon  = new Color(0xaa, 0xaa, 0);
                    //         var clbar = new Color(0x55, 0x4c, 0);
                    //         var cloff = new Color(0x0c, 0x08, 0);
                    //         var clc   = nCharging >= m_batteries.Count/2 ? clon : cloff;

                    //         if (m_help)
                    //         {
                    //             m_display0.Add(ref frame0, DrawString("1", pcl.X, pcl.Y + 28, 0.5f, clon, TextAlignment.CENTER));
                    //}
                    //         else
                    //         { 
                    //             m_display0.Add(ref frame0, DrawTex("CircleHollow", pcl.X-9, pcl.Y-9 + 36, 18, 18, clc));
                    //             m_display0.Add(ref frame0, DrawTex("IconEnergy", pcl.X-8, pcl.Y-8 + 36, 16, 16, clc));
                    //         }

                    //         m_display0.Add(ref frame0, FillRect(pcl.X-7, pcl.Y+20, 14, -30, cloff));
                    //         m_display0.Add(ref frame0, FillRect(pcl.X-7, pcl.Y+20, 14, -30 * batCur/batMax, clbar));


                    //         // nuclear reactor light
                    //         if (m_reactors.Count > 0)
                    //         { 
                    //             var reacOut = 0f;
                    //             var reacU = 0f;
                    //             var enabled = false;

                    //             foreach (var r in m_reactors)
                    //             { 
                    //                 reacOut += r.CurrentOutput;
                    //                 reacU += (float)r.GetInventory(0).CurrentMass;
                    //                 enabled |= r.Enabled;
                    //             }


                    //             if (m_help)
                    //                 m_display0.Add(ref frame0, DrawString("2", 114, m_display0.Viewport.Bottom - 27, 0.5f, clon, TextAlignment.CENTER));
                    //             else
                    //                 m_display0.Add(ref frame0, DrawTex("Textures\\FactionLogo\\Others\\OtherIcon_19.dds", 105, m_display0.Viewport.Bottom - 28, 18, 18, enabled ? new Color(0xaa, 0xaa, 0) : new Color(0x0c, 0x08, 0)));

                    //             m_display0.Add(ref frame0, FillRect(114-7, m_display0.Viewport.Bottom-35, 14, -30, cloff));
                    //             m_display0.Add(ref frame0, FillRect(114-7, m_display0.Viewport.Bottom-35, 14, -30 * Math.Min(Math.Max(0, reacOut/batMax), 1), clbar));

                    //             m_display0.Add(ref frame0, DrawString(printMass(reacU), 127, m_display0.Viewport.Bottom-20, 0.3f, new Color(0x88, 0x82, 0)));
                    //         }


                    //         // far lights
                    //         var pfl = m_display0.Viewport.Center + new Vector2(-110, -9);
                    //         var flc = m_farLights ? new Color(0, 0x44, 0xff) : new Color(0, 0x03, 0x18);
                    //         if (m_help)
                    //         {
                    //             m_display0.Add(ref frame0, DrawString("3", pfl.X + 2, pfl.Y + 29, 0.5f, new Color(0, 0x44, 0xff), TextAlignment.CENTER));
                    //}
                    //         else
                    //         { 
                    //             m_display0.Add(ref frame0, DrawTex("SemiCircle", pfl.X-5, pfl.Y-5 + 37, 11, 11, flc, -Tau/4));
                    //             m_display0.Add(ref frame0, FillRect(pfl.X+9 - 7, pfl.Y-9 + 41, 8, 2, flc));
                    //             m_display0.Add(ref frame0, FillRect(pfl.X+9 - 7, pfl.Y-9 + 44, 8, 2, flc));
                    //             m_display0.Add(ref frame0, FillRect(pfl.X+9 - 7, pfl.Y-9 + 47, 8, 2, flc));
                    //             m_display0.Add(ref frame0, FillRect(pfl.X+9 - 7, pfl.Y-9 + 50, 8, 2, flc));
                    //         }


                    //         // near lights
                    //         var pnl = m_display0.Viewport.Center + new Vector2(-75, -9);
                    //         var nlc = m_lightsOn ? new Color(0, 0xcc, 0) : new Color(0, 0x08, 0);
                    //         if (m_help)
                    //         {
                    //             m_display0.Add(ref frame0, DrawString("L", pnl.X + 4, pnl.Y + 29, 0.5f, new Color(0, 0xcc, 0), TextAlignment.CENTER));
                    //             m_display0.Add(ref frame0, DrawString("4", pnl.X + 4, pnl.Y + 45, 0.3f, new Color(0, 0xcc, 0), TextAlignment.CENTER));
                    //}
                    //         else
                    //         { 
                    //             m_display0.Add(ref frame0, DrawTex("SemiCircle", pnl.X-5, pnl.Y-5 + 37, 10.5f, 10.5f, nlc, -Tau/4));
                    //             m_display0.Add(ref frame0, FillRect(pnl.X+9 - 7, pnl.Y-9 + 41, 8, 1, nlc));
                    //             m_display0.Add(ref frame0, FillRect(pnl.X+9 - 7, pnl.Y-9 + 44, 8, 1, nlc));
                    //             m_display0.Add(ref frame0, FillRect(pnl.X+9 - 7, pnl.Y-9 + 47, 8, 1, nlc));
                    //             m_display0.Add(ref frame0, FillRect(pnl.X+9 - 7, pnl.Y-9 + 50, 8, 1, nlc));

                    //             var alc = m_autoLights ? new Color(0, 0xcc, 0) : new Color(0, 0x08, 0);
                    //             m_display0.Add(ref frame0, DrawString("AUTO", pnl.X + 3, pnl.Y + 45, 0.2f, alc, TextAlignment.CENTER));
                    //         }

                    Echo("2.27");

                    // drive mode P/R/N/D
                    var pdm = m_display0.Viewport.Center + new Vector2(0, 17);
                    var mode = m_cockpit.HandBrake ? "P" : (m_reversing ? "R" : "D");
                    m_display0.Add(ref frame0, FillRect(pdm.X - 12, pdm.Y - 2, 22, 26, new Color(0x04, 0x04, 0x06)));
                    m_display0.Add(ref frame0, DrawString(mode, pdm.X, pdm.Y, 0.7f, Color.Gray, TextAlignment.CENTER));

                    Echo("2.28");

                    // cruise control
                    var pcc = m_display0.Viewport.Center + new Vector2(50, 85);
                    var ccc = m_cruiseControl ? new Color(0, 0xcc, 0) : new Color(0, 0x13, 0);
                    var ccv = new Color(0x66, 0x66, 0x66);
                    var ccl = new Color(0x33, 0x33, 0x33);

                    m_display0.Add(ref frame0, FillRect(pcc.X - 3, pcc.Y - 31, 26, 14, new Color(0x04, 0x04, 0x06)));

                    if (m_cruiseControl)
                        m_display0.Add(ref frame0, DrawString(printValue(m_ccHeading, 0, true, 3), pcc.X+1, pcc.Y - 29, 0.33f, ccv));

                    m_display0.Add(ref frame0, DrawString("°", pcc.X + 25, pcc.Y - 29, 0.2f, ccv));

                    m_display0.Add(ref frame0, FillRect(pcc.X - 3, pcc.Y - 16, 26, 14, new Color(0x04, 0x04, 0x06)));

			        if (m_cruiseControl)
                        m_display0.Add(ref frame0, DrawString(printValue(m_ccSpeed * 3.6f, 0, true, 3), pcc.X+1, pcc.Y - 14, 0.33f, ccv));

                    m_display0.Add(ref frame0, DrawString("km/h", pcc.X + 25, pcc.Y - 11, 0.2f, ccv));

                    m_display0.Add(ref frame0, DrawString("CRUISE", pcc.X-1, pcc.Y, 0.2f, ccc));

                    Echo("2.29");

                    // parking brake
                    var ppl = m_display0.Viewport.Center + new Vector2(60, -8);
                    var plc = m_cockpit.HandBrake ? new Color(0, 0xcc, 0) : new Color(0, 0x13, 0);
                    if (m_help)
                    {
                        m_display0.Add(ref frame0, DrawString("P", ppl.X, ppl.Y + 29, 0.5f, new Color(0, 0xcc, 0), TextAlignment.CENTER));
			        }
                    else
                    { 
                        m_display0.Add(ref frame0, DrawTex("CircleHollow", ppl.X-14, ppl.Y-14 + 36, 28, 28, plc));
                        m_display0.Add(ref frame0, FillRect(ppl.X-20, ppl.Y-13 + 35, 40, 6, Color.Black));
                        m_display0.Add(ref frame0, FillRect(ppl.X-20, ppl.Y-13 + 57, 40, 6, Color.Black));
                        m_display0.Add(ref frame0, DrawTex("CircleHollow", ppl.X-10, ppl.Y-10 + 36, 20, 20, plc));
                        m_display0.Add(ref frame0, DrawString("!", ppl.X, ppl.Y + 30f, 0.4f, plc, TextAlignment.CENTER));
                    }

                    Echo("2.30");

                    // emergency
                    var pel = m_display0.Viewport.Center + new Vector2(100, -10);
                    var elc = m_emergency && m_count10 % blink10 < blink10/2 ? new Color(0xaa, 0, 0) : new Color(0x08, 0, 0);
                    if (m_help)
                    {
                        m_display0.Add(ref frame0, DrawString("8", pel.X, pel.Y + 32, 0.5f, new Color(0xaa, 0, 0), TextAlignment.CENTER));
			        }
                    else
                    { 
                        m_display0.Add(ref frame0, DrawTex("Triangle", pel.X-11, pel.Y-11 + 36, 22, 22, elc));
                        m_display0.Add(ref frame0, DrawTex("Triangle", pel.X-9, pel.Y-9 + 36.7f, 18, 18, Color.Black));
                        m_display0.Add(ref frame0, DrawTex("Triangle", pel.X-6, pel.Y-6 + 38, 12, 12, elc));
                        m_display0.Add(ref frame0, DrawTex("Triangle", pel.X-4, pel.Y-4 + 38.7f, 8, 8, Color.Black));
                    }

                    Echo("2.31");

                    // left turn
                    var plt = m_display0.Viewport.Position + new Vector2(4, 17);
                    var ltc = (m_turningLeft || m_emergency) && m_count10 % blink10 < blink10/2 ? new Color(0, 0xcc, 0) : new Color(0, 0x08, 0);
                    m_display0.Add(ref frame0, DrawTex("Triangle", plt.X-8 + 10, plt.Y-8, 16, 16, ltc, -Tau/4));
                    m_display0.Add(ref frame0, FillRect(plt.X-4 + 20, plt.Y-4, 8, 8, ltc));


                    // right turn
                    var prt = m_display0.Viewport.Position + new Vector2(m_display0.Viewport.Width - 4, 17);
                    var rtc = (m_turningRight || m_emergency) && m_count10 % blink10 < blink10/2  ? new Color(0, 0xcc, 0) : new Color(0, 0x08, 0);
                    m_display0.Add(ref frame0, DrawTex("Triangle", prt.X-8 - 10, prt.Y-8, 16, 16, rtc, Tau/4));
                    m_display0.Add(ref frame0, FillRect(prt.X-4 - 20, prt.Y-4, 8, 8, rtc));


                    m_display0.Add(ref frame0, DrawString("HELP 9", m_display0.Viewport.Right - 8, m_display0.Viewport.Bottom - 20, 0.4f, m_help ? Color.Gray : new Color(0x44, 0x44, 0x44), TextAlignment.RIGHT));


                    frame0.Dispose();



                    Echo("2.32");
                    var x2 = m_display2.Viewport.Center.X - 80;
			        var y2 = 0;

			        var line2  = 0;
			        var step2  = 16;

                    var scale2 = 0.5f;

                    m_display2.ContentWidth  = m_display2.Viewport.Width;
                    m_display2.ContentHeight = m_display2.Viewport.Height;//7*step2;

                    var frame2 = m_display2.Surface.DrawFrame();


                    // roll gauge

                    var rSize = 70;

			        var xr = m_display2.Viewport.Width - 50;
			        var yr = 170 - rSize/2;

                    m_display2.Add(ref frame2, DrawTex("Circle", xr - rSize/2, yr - rSize/2, rSize, rSize, colGauge));

			        m_display2.Add(ref frame2, DrawString("R", xr, yr + 8, 0.5f, colLabel, TextAlignment.CENTER));

                    for (float a = 0; a < Tau; a += Tau/8)
                    {
                        var v = vector2(a, rSize/2 + 5);
    			        //m_display2.Add(ref frame2, DrawString(printValue(p, 0, true, 0), xr + v.X*1.02f, yr + v.Y*1.02f * 1.1f - 5, 0.35f, Color.Gray, p < 20 || p > 80 ? TextAlignment.CENTER : TextAlignment.RIGHT));
    			        m_display2.Add(ref frame2, DrawLine(xr + v.X*0.7, yr + v.Y*0.7f, xr + v.X*0.89f, yr + v.Y*0.89f, Color.Gray, 3));
			        }

    		        m_display2.Add(ref frame2, DrawLine(xr - rSize/2 - 7, yr, xr + rSize/2 + 7, yr, Color.Gray, 1));
                    Echo("2.33");

                    var vr = vector2(m_orientation.Z * Tau/2, rSize/2);
    		        m_display2.Add(ref frame2, DrawLine(xr - vr.X, yr - vr.Y + 4, xr + vr.X, yr + vr.Y + 4, colShadow, 9));
                    m_display2.Add(ref frame2, DrawTex("Circle", xr - 5, yr - 5 + 4, 10, 10, colShadow));
    		        m_display2.Add(ref frame2, DrawLine(xr - vr.X, yr - vr.Y, xr + vr.X, yr + vr.Y, colArrow, 4));
                    m_display2.Add(ref frame2, DrawTex("Circle", xr - 4, yr - 4, 8, 8, colArrow));


                    // pitch gauge

                    var ptSize = 70;

			        var xpt = m_display2.Viewport.X + 232;
			        var ypt = 85 - ptSize/2;

                    m_display2.Add(ref frame2, DrawTex("Circle", xpt - ptSize/2, ypt - ptSize/2, ptSize, ptSize, colGauge));
                    m_display2.Add(ref frame2, FillRect(xpt + 13, ypt - 40, xpt + 50, ypt + 40, Color.Black));

			        m_display2.Add(ref frame2, DrawString("P", xpt - 6, ypt + 8, 0.5f, colLabel, TextAlignment.CENTER));

                    for (float a = Tau/4; a <= Tau*3/4; a += Tau/8)
                    {
                        var v = vector2(a, ptSize/2 + 5);
    			        //m_display2.Add(ref frame2, DrawString(printValue(p, 0, true, 0), xpt + v.X*1.02f, ypt + v.Y*1.02f * 1.1f - 5, 0.35f, Color.Gray, p < 20 || p > 80 ? TextAlignment.CENTER : TextAlignment.RIGHT));
    			        m_display2.Add(ref frame2, DrawLine(xpt + v.X*0.7, ypt + v.Y*0.7f, xpt + v.X*0.89f, ypt + v.Y*0.89f, Color.Gray, 3));
			        }

    		        m_display2.Add(ref frame2, DrawLine(xpt - ptSize/2 - 7, ypt, xpt + 10, ypt, Color.Gray, 1));

			        var vpt = vector2(Tau/2 + Math.Min(m_orientation.X, 1) * Tau/2, ptSize/2);
    		        m_display2.Add(ref frame2, DrawLine(xpt, ypt + 4, xpt + vpt.X, ypt + vpt.Y + 4, colShadow, 9));
                    m_display2.Add(ref frame2, DrawTex("Circle", xpt - 5, ypt - 5 + 4, 10, 10, colShadow));
    		        m_display2.Add(ref frame2, DrawLine(xpt, ypt, xpt + vpt.X, ypt + vpt.Y, colArrow, 4));
                    m_display2.Add(ref frame2, DrawTex("Circle", xpt - 4, ypt - 4, 8, 8, colArrow));

                    Echo("2.34");

                    // location

                    line2 = 0;
                    m_display2.Add(ref frame2, DrawString(/*"LON " + */printCoord(m_longitude, "W", "E"), 10, y2 + 150 + line2++*step2, 0.36f, Color.Gray));
                    m_display2.Add(ref frame2, DrawString(/*"LAT " + */printCoord(m_latitude, "S", "N"),  10, y2 + 150 + line2++*step2, 0.36f, Color.Gray));



                    // compass

                    var cSize = 80;

			        var xc = m_display2.Viewport.X + 97;
			        var yc = m_display2.Viewport.Y + 80 - cSize/2;

                    m_display2.Add(ref frame2, DrawTex("Circle", xc - cSize/2, yc - cSize/2, cSize, cSize, colGauge));

                    for (float a = 0; a < Tau; a += Tau/12)
                    {
                        var v  = vector2(-m_heading/360*Tau + a, cSize/2 + 5);
                        var v1 = vector2(-m_heading/360*Tau + a + Tau/36, cSize/2 + 5);
                        var v2 = vector2(-m_heading/360*Tau + a + Tau/18, cSize/2 + 5);

                        if (   Math.Abs(a          ) > 0.001
                            && Math.Abs(a - Tau/4  ) > 0.001
                            && Math.Abs(a - Tau/2  ) > 0.001
                            && Math.Abs(a - Tau*3/4) > 0.001)
        			        m_display2.Add(ref frame2, DrawLine(xc + v.X*0.78, yc + v.Y*0.78f, xc + v.X*0.89f, yc + v.Y*0.89f, Color.Gray, 3));

    			        m_display2.Add(ref frame2, DrawLine(xc + v1.X*0.85, yc + v1.Y*0.85f, xc + v1.X*0.89f, yc + v1.Y*0.89f, Color.Gray, 1));
    			        m_display2.Add(ref frame2, DrawLine(xc + v2.X*0.85, yc + v2.Y*0.85f, xc + v2.X*0.89f, yc + v2.Y*0.89f, Color.Gray, 1));
			        }


                    m_display2.Add(ref frame2, DrawTex("Triangle", xc-5, yc-6 - cSize/2+10, 10, 12, Color.Gray));

                    Echo("2.35");

                    var heading = -m_heading/360*Tau;

                    var vn = vector2(heading - Tau/4, cSize/2);
                    m_display2.Add(ref frame2, DrawTex("Triangle", xc+vn.X - 5, yc+vn.Y - 5, 10, 10, new Color(0x88, 0, 0), heading));


                    for (float a = 0; a <= Tau/2; a += Tau/4)
                    {
                        var vs = vector2(heading + a, cSize/2);
                        m_display2.Add(ref frame2, DrawTex("Triangle", xc+vs.X - 4, yc+vs.Y - 4, 8, 8, Color.Gray, heading + Tau/4 + a));
			        }

                    m_display2.Add(ref frame2, DrawString(printValue(m_heading, 0, true, 3) + "°", xc + 2, yc - 8, scale2, Color.Gray, TextAlignment.CENTER));


                    Echo("2.36");

                    // altitude

                    m_display2.Add(ref frame2, DrawString(printValue(m_altitude, 0, true, 5) + " m", 115, m_display2.Viewport.Height - 26, 0.4f, Color.Gray));


                    Echo("2.37");

                    frame2.Dispose();



                    m_display1.ContentWidth  = m_display1.Viewport.Width;
                    m_display1.ContentHeight = m_display1.Viewport.Height;

                    var frame1 = m_display1.Surface.DrawFrame();

                    // mass
                    //var colMove = new Color(0x66, 0x66, 0);

                    var ptr = new Vector2(25, 60);

                    var size = 45;

            
                    //m_display1.Add(ref frame1, DrawConnector(ptr.X - 16, ptr.Y + 8, 14, size - 16, m_connector));

                    //var n = 0;
                    //m_display1.Add(ref frame1, DrawCollector(ptr.X + n++*(size+2), ptr.Y, size, m_rearMass,   m_rearFull));
                    //m_display1.Add(ref frame1, DrawCargo    (ptr.X + n++*(size+2), ptr.Y, size, m_cargo3mass, m_cargo3full));
                    //m_display1.Add(ref frame1, DrawCargo    (ptr.X + n++*(size+2), ptr.Y, size, m_cargo2mass, m_cargo2full));
                    //m_display1.Add(ref frame1, DrawCargo    (ptr.X + n++*(size+2), ptr.Y, size, m_cargo1mass, m_cargo1full));
                    //m_display1.Add(ref frame1, DrawCabin    (ptr.X + n++*(size+2), ptr.Y+4, size-8));

                    //m_display1.Add(ref frame1, DrawString(printMass(m_mass), m_display1.Viewport.Width - 40, 10, 0.5f, Color.Gray, TextAlignment.RIGHT));

                    //var move = " ";
                    //     if (m_mass < m_prevMass) move = "◄";
                    //else if (m_mass > m_prevMass && (m_connector != null && m_connector.Status == MyShipConnectorStatus.Connected)) move = "►";

                    //var drop = 
                    //    m_mass > m_prevMass && (m_connector == null || m_connector.Status != MyShipConnectorStatus.Connected)
                    //    ? "▼"
                    //    : " ";

                    //m_display1.Add(ref frame1, DrawString(move, ptr.X - 9, ptr.Y + size/2 - 5, 0.4f, colMove, TextAlignment.CENTER));
                    //m_display1.Add(ref frame1, DrawString(drop, ptr.X + size/2, ptr.Y + size*0.3f - 5, 0.4f, colMove, TextAlignment.CENTER));


                    //var ww = 30;
                    //var ws = 10;

                    //n = 0;
                    //m_display1.Add(ref frame1, DrawWheel(ptr.X + n++*(size+2) + size/2, ptr.Y + 40 + size/2, ww));
                    //m_display1.Add(ref frame1, DrawWheel(ptr.X + n++*(size+2) + size/2, ptr.Y + 40 + size/2, ww));
                    //m_display1.Add(ref frame1, DrawWheel(ptr.X + n++*(size+2) + size/2, ptr.Y + 40 + size/2, ww));
                    //m_display1.Add(ref frame1, DrawWheel(ptr.X + n++*(size+2) + size/2, ptr.Y + 40 + size/2, ww));

                    //if (m_susp.Count == 4)
                    //{
                    //    n = 0;
                    //    m_display1.Add(ref frame1, DrawSuspension(ptr.X + n++*(size+2) + size/2 - ws/2, ptr.Y + size/2 + 24, ws, 16, m_susp[3]));
                    //    m_display1.Add(ref frame1, DrawSuspension(ptr.X + n++*(size+2) + size/2 - ws/2, ptr.Y + size/2 + 24, ws, 16, m_susp[2]));
                    //    m_display1.Add(ref frame1, DrawSuspension(ptr.X + n++*(size+2) + size/2 - ws/2, ptr.Y + size/2 + 24, ws, 16, m_susp[1]));
                    //    m_display1.Add(ref frame1, DrawSuspension(ptr.X + n++*(size+2) + size/2 - ws/2, ptr.Y + size/2 + 24, ws, 16, m_susp[0]));
                    //}


                    //if (m_kneel)
                    //{
                    //    var colDown = new Color(0x22, 0x22, 0x22);

                    //    var aw = 25;
                    //    var ah = 25;

                    //    m_display1.Add(ref frame1, DrawTex("Triangle", ptr.X + 4*(size+2) + size/2 - 4 - aw/2, ptr.Y + size + 4 + ah/3, aw, ah*2/3f, colDown, Tau/2));
                    //    m_display1.Add(ref frame1, FillRect(           ptr.X + 4*(size+2) + size/2 - 4 - aw/4, ptr.Y + size + 4,        aw/2, ah/3, colDown));
                    //}

                    if (m_help)
                        m_display1.Add(ref frame1, DrawString("7", ptr.X + 4*(size+2) + size/2 - 3, ptr.Y + size + 7, 0.5f, new Color(0xaa, 0xaa, 0xaa), TextAlignment.CENTER));
                    Echo("2.38");


                    frame1.Dispose();
		        }


                m_count10++;

                m_lastMove10   = m_move;
                m_lastRotate10 = m_rotate;
            }
            Echo("3");

            if ((update & UpdateType.Update100) != 0)
            {
                var cockpits = new List<IMyCockpit>();
                GridTerminalSystem.GetBlocksOfType(cockpits);

                if (cockpits.Count > 0)
                    m_cockpit = cockpits[0];

                if (m_cockpit != null)
                { 
                    m_cockpit.ControlWheels    = false;
                    m_cockpit.ControlThrusters = false;


                    m_prevMass = m_mass;

                    m_mass = 1000;
                        //  m_cargo1mass 
                        //+ m_cargo2mass 
                        //+ m_cargo3mass 
                        //+ m_rearMass;


                    if (m_display0 == null || m_display0.Provider != m_cockpit) m_display0 = new Display(m_cockpit, 0);
                    if (m_display2 == null || m_display2.Provider != m_cockpit) m_display2 = new Display(m_cockpit, 2); 
                    if (m_display1 == null || m_display1.Provider != m_cockpit) m_display1 = new Display(m_cockpit, 1); 

                    GridTerminalSystem.GetBlocksOfType(m_lWheels, w => w.Position.X < m_cockpit.Position.X);
                    GridTerminalSystem.GetBlocksOfType(m_rWheels, w => w.Position.X > m_cockpit.Position.X);


                    var nWheels = Math.Max(m_lWheels.Count, m_rWheels.Count);

                    if (nWheels != m_susp.Count)
                    { 
                        var defSusp = 5f;

                        m_susp.Clear();
                        for (int i = 0; i < nWheels; i++)
                            m_susp.Add(defSusp);
                    }


                    m_lWheels = m_lWheels.OrderBy(w => -w.Position.Z).ToList();
                    m_rWheels = m_rWheels.OrderBy(w => -w.Position.Z).ToList();

                    m_midZ = 0;

                    foreach (var lw in m_lWheels) m_midZ += lw.Position.Z;
                    foreach (var rw in m_lWheels) m_midZ += rw.Position.Z;

                    if (   m_lWheels.Count > 0 
                        || m_rWheels.Count > 0)
                        m_midZ /= m_lWheels.Count + m_rWheels.Count;

                    m_minZ = m_midZ;
                    m_maxZ = m_midZ;

                    m_flw = null;
                    m_frw = null;
                    m_rlw = null;
                    m_rrw = null;

                    foreach (var lw in m_lWheels) 
                    { 
                        m_minZ = Math.Min(m_minZ, lw.Position.Z); 
                        m_maxZ = Math.Max(m_maxZ, lw.Position.Z); 

                        if (lw.Position.Z == m_maxZ) m_flw = lw; 
                        if (lw.Position.Z == m_minZ) m_rlw = lw; 
                    }

                    foreach (var rw in m_rWheels) 
                    { 
                        m_minZ = Math.Min(m_minZ, rw.Position.Z); 
                        m_maxZ = Math.Max(m_maxZ, rw.Position.Z); 

                        if (rw.Position.Z == m_maxZ) m_frw = rw; 
                        if (rw.Position.Z == m_minZ) m_rrw = rw; 
                    }

			        var _lw = GridTerminalSystem.GetBlockWithName("Wheel L1") as IMyMotorSuspension;
                    var _rw = GridTerminalSystem.GetBlockWithName("Wheel R1") as IMyMotorSuspension;

              //      if (    m_cockpit.IsUnderControl
              //          && !m_kneelFromInside
              //          && _lw != null
              //          && _rw != null 
              //          &&  m_kneel)
              //      {
              //          m_kneel = false;
		            //}
            
              //      if (!m_cockpit.IsUnderControl)
              //          m_kneelFromInside = false;
		        }

                m_centBlock = GridTerminalSystem.GetBlockWithName("Gyroscope") as IMyGyro;
                m_fwdBlock  = GridTerminalSystem.GetBlockWithName("Antenna") as IMyRadioAntenna;
                m_upBlock   = GridTerminalSystem.GetBlockWithName("Collector") as IMyCollector;

                //m_headlights.Clear();
                //GridTerminalSystem.GetBlocksOfType(m_headlights);

                //if (m_autoLights)
                //{
                //    foreach (var h in m_headlights)
                //        h.Enabled = m_curSolarPower < 0.002;
                //}


                //m_lightFL = GridTerminalSystem.GetBlockWithName("Turn Light L") as IMyInteriorLight;
                //m_lightFR = GridTerminalSystem.GetBlockWithName("Turn Light R") as IMyInteriorLight;
                //m_lightBL = GridTerminalSystem.GetBlockWithName("Rear Light L") as IMyInteriorLight;
                //m_lightBR = GridTerminalSystem.GetBlockWithName("Rear Light R") as IMyInteriorLight;

                //m_batteries.Clear();
                //GridTerminalSystem.GetBlocksOfType(m_batteries);

                //m_curBatteryPower = GetTotal<IMyBatteryBlock>(b => b.CustomName != "Starter Battery" ? b.CurrentStoredPower : 0);
                //m_maxBatteryPower = GetTotal<IMyBatteryBlock>(b => b.CustomName != "Starter Battery" ? b.MaxStoredPower     : 0);

                //m_curSolarPower += (GetTotal<IMySolarPanel>(p => p.CurrentOutput) - m_curSolarPower) * 0.45f;
                //m_maxSolarPower  = GetTotal<IMySolarPanel>(p => 0.13f);


                GridTerminalSystem.GetBlocksOfType(m_beepBlocks, b => b.CustomName.ToLower().Contains("reverse"));

                //GridTerminalSystem.GetBlocksOfType(m_reactors);
            }
            Echo("4");


            Echo("Car control");
    
            m_instCount += (this.Runtime.CurrentInstructionCount - m_instCount) * 0.01f;
            Echo("Complexity: " + ((int)m_instCount).ToString() + "/" + this.Runtime.MaxInstructionCount.ToString());
        }
    }
}
